import { useNavigate } from "react-router-dom";
import Login from "../components/Auth/Login";

const LoginPage = () => {
  const navigate = useNavigate();

  return (
    <Login
      goToRegister={() => navigate("/register")} 
      onLoginSuccess={() => navigate("/dashboard")}
    />
  );
};

export default LoginPage;
