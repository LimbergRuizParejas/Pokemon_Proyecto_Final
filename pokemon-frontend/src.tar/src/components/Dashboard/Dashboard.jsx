import { useEffect, useState, useContext } from "react";
import api from "../../api/api";
import { AuthContext } from "../../context/AuthContext";

const Dashboard = () => {
  const [pokemones, setPokemones] = useState([]);
  const { user, logout } = useContext(AuthContext);

  useEffect(() => {
    const fetchPokemones = async () => {
      try {
        const res = await api.get("user-pokemones/");
        setPokemones(res.data.equipo); 
      } catch (err) {
        console.error(err);
      }
    };
    fetchPokemones();
  }, []);

  const containerStyle = {
    maxWidth: "900px",
    margin: "2rem auto",
    padding: "2rem",
    backgroundColor: "#2b2b2b",
    borderRadius: "1rem",
    boxShadow: "0 0 20px rgba(0,0,0,0.5)",
    color: "#f5f5f5",
  };

  const headerStyle = {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  };

  const cardStyle = {
    backgroundColor: "#333",
    padding: "1rem",
    borderRadius: "0.75rem",
    flex: "1 1 150px",
    textAlign: "center",
    margin: "0.5rem",
    transition: "transform 0.2s",
  };

  const cardContainerStyle = {
    display: "flex",
    flexWrap: "wrap",
    gap: "1rem",
    marginTop: "2rem",
  };

  return (
    <div style={containerStyle}>
      <div style={headerStyle}>
        <h1>Bienvenido, {user?.username}</h1>
        <button onClick={logout} style={{ padding: "0.5rem 1rem", borderRadius: "0.5rem", backgroundColor: "#ff0000", color: "white", border: "none", cursor: "pointer" }}>Cerrar Sesión</button>
      </div>

      <h2 style={{ color: "#f7d842" }}>Mi Equipo</h2>
      <div style={cardContainerStyle}>
        {pokemones.map((up) => (
          <div key={up.id} style={cardStyle}>
            <h3 style={{ color: "#f7d842" }}>{up.pokemon.name}</h3>
            <p>Nivel: {up.nivel}</p>
            <p>HP: {up.current_hp}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
