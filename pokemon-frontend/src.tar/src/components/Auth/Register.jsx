import { useState } from "react";
import api from "../../api/api";

const Register = ({ onRegisterSuccess }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  // Estilos inline
  const formStyle = {
    display: "flex",
    flexDirection: "column",
    width: "300px",
    margin: "5rem auto",
    padding: "2rem",
    backgroundColor: "#2b2b2b",
    borderRadius: "1rem",
    boxShadow: "0 0 20px rgba(0,0,0,0.5)",
    color: "#f5f5f5",
  };

  const inputStyle = {
    marginBottom: "1rem",
    padding: "0.5rem",
    borderRadius: "0.5rem",
    border: "1px solid #555",
    backgroundColor: "#1f1f1f",
    color: "white",
  };

  const buttonStyle = {
    padding: "0.5rem 1rem",
    borderRadius: "0.5rem",
    border: "none",
    backgroundColor: "#ff0000",
    color: "white",
    fontWeight: "bold",
    cursor: "pointer",
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post("auth/register/", { username, password });
      onRegisterSuccess();
    } catch (err) {
      setError("Error al registrar usuario");
      console.error(err);
    }
  };

  return (
    <form style={formStyle} onSubmit={handleSubmit}>
      <h2 style={{ textAlign: "center", marginBottom: "1rem", color: "#f7d842" }}>Registro</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <input
        type="text"
        placeholder="Usuario"
        style={inputStyle}
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        required
      />
      <input
        type="password"
        placeholder="Contraseña"
        style={inputStyle}
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      <button type="submit" style={buttonStyle}>Registrarse</button>
    </form>
  );
};

export default Register;
