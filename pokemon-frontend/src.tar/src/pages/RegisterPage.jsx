import { useNavigate } from "react-router-dom";
import Register from "../components/Auth/Register";

const RegisterPage = () => {
  const navigate = useNavigate();
  return <Register onRegisterSuccess={() => navigate("/login")} />;
};

export default RegisterPage;
