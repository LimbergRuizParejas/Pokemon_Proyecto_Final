import { useState, useContext } from "react";
import { AuthContext } from "../../context/AuthContext";

const Login = ({ onLoginSuccess, goToRegister }) => {
  const { login } = useContext(AuthContext);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
  e.preventDefault();
  setError(""); // Limpiar error previo
  try {
    const success = await login(username, password);
    if (success) {
      // Redirigir o ejecutar callback
      onLoginSuccess(); 
    } else {
      setError("Usuario o contraseña incorrectos");
    }
  } catch (err) {
    setError("Error de conexión con el servidor");
    console.error(err);
  }
};


  return (
    <form
      onSubmit={handleSubmit}
      style={{
        display: "flex",
        flexDirection: "column",
        width: "300px",
        margin: "5rem auto",
        padding: "2rem",
        backgroundColor: "#2b2b2b",
        borderRadius: "1rem",
        boxShadow: "0 0 20px rgba(0,0,0,0.5)",
        color: "#f5f5f5",
      }}
    >
      <h2 style={{ textAlign: "center", marginBottom: "1rem", color: "#f7d842" }}>Login</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <input
        type="text"
        placeholder="Usuario"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        required
        style={{
          marginBottom: "1rem",
          padding: "0.5rem",
          borderRadius: "0.5rem",
          border: "1px solid #555",
          backgroundColor: "#1f1f1f",
          color: "white",
        }}
      />
      <input
        type="password"
        placeholder="Contraseña"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
        style={{
          marginBottom: "1rem",
          padding: "0.5rem",
          borderRadius: "0.5rem",
          border: "1px solid #555",
          backgroundColor: "#1f1f1f",
          color: "white",
        }}
      />
      <button
        type="submit"
        style={{
          padding: "0.5rem 1rem",
          borderRadius: "0.5rem",
          border: "none",
          backgroundColor: "#ff0000",
          color: "white",
          fontWeight: "bold",
          cursor: "pointer",
          marginBottom: "1rem",
        }}
      >
        Iniciar Sesión
      </button>
      <button
        type="button"
        onClick={goToRegister}
        style={{
          padding: "0.5rem 1rem",
          borderRadius: "0.5rem",
          border: "none",
          backgroundColor: "#444",
          color: "white",
          cursor: "pointer",
        }}
      >
        Registrarse
      </button>
    </form>
  );
};

export default Login;
