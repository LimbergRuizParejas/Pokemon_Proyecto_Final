import { createContext, useState } from "react";
import api from "../api/api";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  const login = async (username, password) => {
    try {
      const response = await api.post("auth/login/", { username, password });
      const { access, refresh } = response.data;

      // Guardar tokens en localStorage
      localStorage.setItem("access_token", access);
      localStorage.setItem("refresh_token", refresh);

      // Guardar info básica del usuario
      setUser({ username });

      return { success: true };
    } catch (err) {
      console.error("Login error:", err);

      // Puedes devolver detalles para mostrar al usuario
      if (err.response && err.response.status === 401) {
        return { success: false, message: "Usuario o contraseña incorrectos" };
      }
      return { success: false, message: "Error de conexión con el servidor" };
    }
  };

  const logout = () => {
    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
